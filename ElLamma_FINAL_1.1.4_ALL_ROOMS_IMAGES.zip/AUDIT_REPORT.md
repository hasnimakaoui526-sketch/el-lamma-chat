# ElLamma 1.1.2 — Final Hardened Audit

## Release identity
- versionName: `1.1.2`
- versionCode: `13`
- Single release package; no nested APK/ZIP artifacts.

## Backend fixes completed
- Supabase Edge Function `api` deployed and active at version 33.
- Tournament workflow activated: owner creates, users register, owner starts a power-of-two bracket, ready matches create real game matches, completed matches advance automatically, and the final winner becomes champion.
- Seasonal workflow activated: current-season leaderboard, medal history, season creation and season closing with Gold/Silver/Bronze awards.
- Announcements activated for authenticated users and owner-only CRUD.
- Site settings activated for authenticated reads and owner-only writes.
- Cosmetic point unlocks are now transactional: points are reserved once and ownership is recorded in `profile_cosmetic_unlocks`.
- Domino draw/pass is rejected when the current hand contains a legal playable tile.
- Game leaderboard counts actual participating games rather than treating wins as games played.
- Existing server-side game validation, avatar validation, game-table RLS hardening and cosmetics validation retained.

## Database changes in this release
- `tournaments.room_id` added to bind tournament matches to a real game room.
- Tournament/season/announcement indexes added.
- `profile_cosmetic_unlocks` added with RLS and supporting indexes.

## Android/WebView hardening
- WebViewAssetLoader app origin.
- JavaScript enabled only for the application UI.
- DOM storage enabled; database/file/content access disabled.
- Universal file URL access disabled.
- Mixed content disabled.
- JS popups/multiple windows disabled.
- Third-party cookies disabled.
- Cleartext traffic disabled.
- Android backup disabled.

## Profile and identity
- Avatar upload supports JPG/PNG/WebP with client and server 5MB limits and magic-byte validation.
- Name cosmetics are live and server-backed: frame, effect, decoration and color.
- Rank/owner/admin entitlement checks occur on the server.
- Point-unlocked cosmetics are purchased once and remembered server-side.

## Static validation
- HTML/JS syntax check passes.
- Android manifest XML parses.
- Java braces balanced.
- No service-role key embedded in the Android/client source.
- No application HTTP API endpoint; production API is HTTPS.
- Final ZIP integrity checked with `unzip -t`.

## Security status
The Supabase security advisor was re-run after the changes. The only remaining security notice is `auth_leaked_password_protection`: Supabase Auth's Leaked Password Protection is disabled. It must be enabled once in the Supabase Dashboard under Auth/password security. The performance advisor was also re-run; the new tournament foreign-key index and duplicate tournament-match index were corrected. Remaining performance notices are primarily unused historical indexes and intentionally overlapping RLS deny/allow policies; they are informational/performance findings, not an exposed-data finding.

The previous broad multiple-permissive-policy notices were removed from the current security advisor result; intentional deny policies remain defense-in-depth on internal game/content tables.

## Release boundary
This package is the final Android release paired with the deployed backend v33. Do not advertise any older 1.0.x/1.1.0 package as the release.


## Final deep audit 1.1.3
- Removed the frontend dependency on a non-existent `/rooms/:id/stream` endpoint; live room updates now use authenticated 3-second message polling against the deployed messages endpoint.
- Admin room listing now returns `is_game_room`, restoring game-room selection when creating tournaments.
- Supabase API deployed and active at version 34.
- Static JavaScript syntax check: PASS.
- ZIP integrity check: PASS.
