-- ElLamma 1.1.2 production schema additions
alter table public.tournaments add column if not exists room_id uuid references public.rooms(id) on delete restrict;
create index if not exists tournaments_status_starts_idx on public.tournaments(status, starts_at);
create index if not exists tournaments_room_id_idx on public.tournaments(room_id);
create index if not exists tournament_players_tournament_seed_idx on public.tournament_players(tournament_id, seed);
create index if not exists tournament_matches_tournament_round_pos_idx on public.tournament_matches(tournament_id, round_no, bracket_pos);
drop index if exists public.tournament_matches_game_match_idx;
create index if not exists season_medals_season_position_idx on public.season_medals(season_id, position);
create index if not exists seasons_status_dates_idx on public.seasons(status, starts_at, ends_at);
create index if not exists announcements_active_dates_priority_idx on public.announcements(active, starts_at, ends_at, priority desc);
create index if not exists site_settings_key_idx on public.site_settings(key);
create table if not exists public.profile_cosmetic_unlocks (
 user_id uuid not null references public.profiles(id) on delete cascade,
 cosmetic_id uuid not null references public.cosmetic_items(id) on delete cascade,
 unlocked_at timestamptz not null default now(),
 primary key(user_id, cosmetic_id)
);
alter table public.profile_cosmetic_unlocks enable row level security;
drop policy if exists profile_cosmetic_unlocks_deny_anon on public.profile_cosmetic_unlocks;
drop policy if exists profile_cosmetic_unlocks_self on public.profile_cosmetic_unlocks;
create policy profile_cosmetic_unlocks_deny_anon on public.profile_cosmetic_unlocks for all to anon using(false) with check(false);
create policy profile_cosmetic_unlocks_self on public.profile_cosmetic_unlocks for select to authenticated using((select auth.uid())=user_id);
create index if not exists profile_cosmetic_unlocks_user_idx on public.profile_cosmetic_unlocks(user_id);
create index if not exists profile_cosmetic_unlocks_cosmetic_idx on public.profile_cosmetic_unlocks(cosmetic_id);

-- Release 1.1.3: API/UI compatibility fixes are deployed in Edge Function v34.
