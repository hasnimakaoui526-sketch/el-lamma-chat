ElLamma 1.1.3 — FINAL RELEASE

Android release package for ElLamma.

Active production features:
- Authentication, 18+ guest access, sessions and ban protection.
- Rooms, chat, presence, friends and private moderation center.
- Profile avatar upload (JPG/PNG/WebP, server validation, 5MB cap).
- Modern name cosmetics: frames, glow/effects, decorations and colors.
- Rank/owner/admin cosmetic entitlements and point-based unlocks with server-side ownership.
- Arcade: Ludo, Domino and Girls Style, matchmaking, invites, queue, XP, stats, achievements, history and leaderboard.
- Domino draw restriction: a player cannot draw/pass while holding a playable tile.
- Knockout tournaments: registration, bracket creation, live tournament matches, automatic advancement and champion recording.
- Seasons: live seasonal leaderboard and Gold/Silver/Bronze medal awarding on season close.
- Announcements and site settings with owner-only management.
- Hardened Android WebView using WebViewAssetLoader and HTTPS-only API access.

Production backend:
- Supabase project: bfbzgzletoaxyazugjex
- Edge Function api: active version 33

Known external action still required:
- Enable Supabase Auth Leaked Password Protection in the Supabase Dashboard. This is an Auth project setting and is not controlled by the Android package.

Build:
- compileSdk 35 / targetSdk 35 / minSdk 23
- versionCode 14 / versionName 1.1.3
- AndroidX WebKit 1.12.1


RELEASE HARDENING NOTE (2026-10-08)
- CI release build is pinned to Gradle 8.9 and verifies the generated APK and SHA-256.
- Supabase Auth leaked-password protection must be enabled in the project's Auth settings (password_hibp_enabled=true). This is a hosted Supabase control and is not embedded in the Android APK.
